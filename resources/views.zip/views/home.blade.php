@extends('admin')

@section('myContent')

<div class="row">
	<h1>Bienvenido al sitema montt</h1>	
</div>
@endsection