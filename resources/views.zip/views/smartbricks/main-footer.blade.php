<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        soporte@smartbricks.com
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2018 <a href="#"></a>.</strong> Todos los derechos reservados.
</footer>